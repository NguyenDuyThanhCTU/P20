import React from "react";

const Price = () => {
  return <div>Cập nhật sau</div>;
};

export default Price;
