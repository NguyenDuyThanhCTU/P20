import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyAD3kQuBCwT6XFTpLWRMYuQjUbDpG3Oxkk",

  authDomain: "suanhacantho-3b53d.firebaseapp.com",

  projectId: "suanhacantho-3b53d",

  storageBucket: "suanhacantho-3b53d.appspot.com",

  messagingSenderId: "722929821674",

  appId: "1:722929821674:web:9065911cc542f64b19b493",

  measurementId: "G-7XFHJCFWMH",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
